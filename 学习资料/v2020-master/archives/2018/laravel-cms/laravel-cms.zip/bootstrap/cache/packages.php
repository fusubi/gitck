<?php return array (
  'barryvdh/laravel-ide-helper' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\LaravelIdeHelper\\IdeHelperServiceProvider',
    ),
  ),
  'dingo/api' => 
  array (
    'providers' => 
    array (
      0 => 'Dingo\\Api\\Provider\\LaravelServiceProvider',
    ),
    'aliases' => 
    array (
      'API' => 'Dingo\\Api\\Facade\\API',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'houdunwang/laravel-autocreate' => 
  array (
    'providers' => 
    array (
      0 => '\\Houdunwang\\AutoCreate\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'HDModule' => '\\Houdunwang\\AutoCreate\\Factory',
    ),
  ),
  'houdunwang/laravel-module' => 
  array (
    'providers' => 
    array (
      0 => '\\Houdunwang\\Module\\LaravelServiceProvider',
    ),
    'aliases' => 
    array (
      'HDModule' => '\\Houdunwang\\Module\\Factory',
    ),
  ),
  'houdunwang/laravel-upload' => 
  array (
    'providers' => 
    array (
      0 => 'Houdunwang\\LaravelUpload\\ServiceProvider',
    ),
    'aliases' => 
    array (
    ),
  ),
  'houdunwang/wechat' => 
  array (
    'providers' => 
    array (
      0 => '\\Houdunwang\\WeChat\\WeChatProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nwidart/laravel-modules' => 
  array (
    'providers' => 
    array (
      0 => 'Nwidart\\Modules\\LaravelModulesServiceProvider',
    ),
    'aliases' => 
    array (
      'Module' => 'Nwidart\\Modules\\Facades\\Module',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'tymon/jwt-auth' => 
  array (
    'aliases' => 
    array (
      'JWTAuth' => 'Tymon\\JWTAuth\\Facades\\JWTAuth',
      'JWTFactory' => 'Tymon\\JWTAuth\\Facades\\JWTFactory',
    ),
    'providers' => 
    array (
      0 => 'Tymon\\JWTAuth\\Providers\\LaravelServiceProvider',
    ),
  ),
);