<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Base\\Providers\\BaseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Base\\Providers\\BaseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);