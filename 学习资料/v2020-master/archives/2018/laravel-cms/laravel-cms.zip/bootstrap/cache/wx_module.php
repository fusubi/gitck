<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Wx\\Providers\\WxServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Wx\\Providers\\WxServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);