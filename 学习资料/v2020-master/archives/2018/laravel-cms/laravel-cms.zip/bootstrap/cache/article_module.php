<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Article\\Providers\\ArticleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Article\\Providers\\ArticleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);