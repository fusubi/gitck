define(['https://cdn.bootcss.com/bootstrap-filestyle/2.1.0/bootstrap-filestyle.min.js'], function ($) {
    return function (el) {
        return $(el).filestyle();
    }
})