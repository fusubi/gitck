<?php return array (
  'name' => '文章系统',
  'template' => 'default',
);