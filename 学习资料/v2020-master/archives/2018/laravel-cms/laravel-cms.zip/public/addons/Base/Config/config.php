<?php

return [
    'name' => '基本回复'
];
