<?php

return [
    'name' => 'News'
];
