<?php

return [
    'name' => '微信公众号'
];
