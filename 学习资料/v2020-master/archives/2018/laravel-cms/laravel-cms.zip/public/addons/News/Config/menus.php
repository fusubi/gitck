<?php return array (
  'wx' => 
  array (
    'title' => '微信管理',
    'icon' => 'fa fa-navicon',
    'permission' => '权限标识',
    'menus' => 
    array (
      0 => 
      array (
        'title' => '配置管理',
        'permission' => '',
        'url' => '/wx/wx_config',
      ),
      1 => 
      array (
        'title' => '基本回复',
        'permission' => '',
        'url' => '/base/base',
      ),
      2 => 
      array (
        'title' => '图文消息',
        'permission' => '',
        'url' => '/news/news',
      ),
    ),
  ),
  0 => 
  array (
    'title' => '菜单管理',
    'icon' => 'fa fa-navicon',
    'permission' => '权限标识',
    'menus' => 
    array (
      0 => 
      array (
        'title' => '微信菜单',
        'permission' => '',
        'url' => '/wx/wx_menu',
      ),
    ),
  ),
  'news' => 
  array (
    'title' => '图文消息管理',
    'icon' => 'fa fa-navicon',
    'permission' => '权限标识',
    'menus' => 
    array (
      0 => 
      array (
        'title' => '图文消息管理',
        'permission' => '',
        'url' => '/news/news',
      ),
    ),
  ),
);