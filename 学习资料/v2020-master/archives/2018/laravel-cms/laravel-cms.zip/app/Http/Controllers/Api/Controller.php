<?php

namespace App\Http\Controllers\Api;

use Dingo\Api\Routing\Helpers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller as LaravelController;

class Controller extends LaravelController
{
    use Helpers;
}
